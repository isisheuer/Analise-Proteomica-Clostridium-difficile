FastProtein Software 1.0
========================
##### Protein Information Software

---
### Summary
| Information                          | Value              |
| ------------------------------------ | ------------------ |
| Processed proteins                   | 3846               |
| Molecular mass (kda) mean            | 34.47 &#177; 23.71 |
| Isoelectric point mean               | 6.80 &#177; 1.83   |
| Hydrophicity mean                    | -0.15 &#177; 0.47  |
| Aromaticity mean                     | 0.09 &#177; 0.03   |
| Proteins with TM                     | 985                |
| Proteins with SP                     | 351                |
| Proteins with GPI                    | 16                 |
| Membrane proteins                    | 1004               |
| Proteins with E.R Retention domains  | 579                |
| Proteins with NGlycosylation domains | 2853               |
### Molecular mass (kDa) vs Isoelectric point (pH)
![Molecular mass (kDa) vs Isoelectric point (pH)](image/kda-vs-pi.png)
---
### Subcellular localization (by WolfPSort) - Organism: animal

![Subcellular Localizations](image/subcell-resume-bar.png)
![Subcellular Localizations](image/subcell-resume-pie.png)

| Subcellular localization | Proteins |
| ------------------------ | -------- |
| Cytosol                  | 2223     |
| Plasma membrane          | 654      |
| Extracellular            | 489      |
| Other                    | 143      |
| Mitochondrion            | 99       |
| Cytoskeleton             | 88       |
| Nucleus                  | 84       |
| E.R                      | 59       |
| Peroxisome               | 6        |
| Lysosome                 | 1        |
---
### E.R Retention domain summary
| Domain | Quantity |
| ------ | -------- |
| KEEL   | 115      |
| KDEL   | 61       |
| AEEL   | 40       |
| KNEL   | 46       |
| ANEL   | 32       |
| REEL   | 46       |
| SDEL   | 30       |
| KQEL   | 29       |
| QEEL   | 26       |
| SEEL   | 57       |
Only top 10

---
### NGlyc domain summary
| Domain | Quantity |
| ------ | -------- |
| NNS    | 331      |
| NLS    | 563      |
| NNT    | 249      |
| NKT    | 313      |
| NKS    | 440      |
| NLT    | 346      |
| NIT    | 372      |
| NIS    | 699      |
| NVS    | 342      |
| NSS    | 321      |
Only top 10

---
| Id         | Length |  kDa  | Isoelectric_Point | Hydropathy | Aromaticity |  Localization   | TMHMM_2 | Phobius_TM | PredGPI | Membrane_evidences | Membrane_evidences_detail  | SignalP5 | Phobius_SP | ER_Retention_Total | NGlyc_Total | ER_Retention_Domains |                                     NGlyc_Domains                                      |                  Header                   | Local_alignment_description | Gene_Ontology | Interpro_Annotation | PFAM_Annotation | Panther_Annotation |
| ---------- |:------:|:-----:|:-----------------:|:----------:|:-----------:|:---------------:|:-------:|:----------:|:-------:|:------------------:|:--------------------------:|:--------:|:----------:|:------------------:|:-----------:|:--------------------:|:--------------------------------------------------------------------------------------:|:-----------------------------------------:| --------------------------- | ------------- | ------------------- | --------------- | ------------------ |
| A0AC59FU70 |  371   | 42.92 |       9.16        |   -0.44    |    0.09     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      6      |                      |     NKT[153-156];NIS[200-203];NLT[208-211];NIT[225-228];NLS[328-331];NVT[351-354]      |    DNA replication and repair protein     | -                           |               |                     |                 |                    |
| A0AC59FU72 |  633   | 71.12 |       5.75        |   -0.44    |    0.08     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      1      |                      |                                      NKS[229-232]                                      |           DNA gyrase subunit B            | -                           |               |                     |                 |                    |
| A0AC59FU86 |  151   | 17.38 |       8.60        |   -0.33    |    0.09     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      1      |                      |                                       NLT[40-43]                                       |       Cytosine/adenosine deaminase        | -                           |               |                     |                 |                    |
| A0AC59FU96 |  423   | 48.53 |       5.68        |   -0.50    |    0.09     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         1          |      1      |     KNEL[48-52]      |                                      NGS[382-385]                                      |           Seryl-tRNA synthetase           | -                           |               |                     |                 |                    |
| A0AC59FUD1 |  257   | 30.03 |       5.84        |   -0.57    |    0.11     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      1      |                      |                                        NAT[5-8]                                        |       RNA polymerase sigma-B factor       | -                           |               |                     |                 |                    |
| A0AC59FUD8 |  368   | 41.60 |       4.88        |   -0.11    |    0.07     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      1      |                      |                                      NDT[225-228]                                      |      DNA polymerase III subunit beta      | -                           |               |                     |                 |                    |
| A0AC59FUE3 |  439   | 50.25 |       6.66        |   -0.34    |    0.08     |  Cytoskeleton   |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      0      |                      |                                                                                        | Chromosomal replication initiator protein | -                           |               |                     |                 |                    |
| A0AC59FUF6 |  808   | 91.09 |       6.45        |   -0.33    |    0.05     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      5      |                      |             NLT[54-57];NGS[167-170];NYS[475-478];NKS[630-633];NIS[738-741]             |           DNA gyrase subunit A            | -                           |               |                     |                 |                    |
| A0AC59FUG1 |  105   | 11.89 |       6.08        |   -0.18    |    0.06     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      0      |                      |                                                                                        |      Anti-sigma-B factor antagonist       | -                           |               |                     |                 |                    |
| A0AC59FUG4 |   98   | 11.21 |       4.82        |   -0.62    |    0.08     |  Extracellular  |    1    |     1      |    -    |         2          |     PHOBIUS_TM&#124;TM     |    -     |     -      |         0          |      0      |                      |                                                                                        |            Gas vesicle protein            | -                           |               |                     |                 |                    |
| A0AC59FUH8 |   86   | 9.59  |       9.48        |    0.32    |    0.08     |  Extracellular  |    1    |     1      |    -    |         2          |     PHOBIUS_TM&#124;TM     |    -     |     -      |         0          |      1      |                      |                                       NAS[54-57]                                       |             Membrane protein              | -                           |               |                     |                 |                    |
| A0AC59FUI0 |  135   | 14.90 |       4.41        |   -0.09    |    0.06     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      0      |                      |                                                                                        |           Serine-protein kinase           | -                           |               |                     |                 |                    |
| A0AC59FUI2 |  457   | 50.27 |       7.52        |   -0.07    |    0.06     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      1      |                      |                                      NLS[151-154]                                      |          DNA repair protein RadA          | -                           |               |                     |                 |                    |
| A0AC59FUI3 |  356   | 40.37 |       5.55        |   -0.07    |    0.07     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         1          |      0      |    SEEL[258-262]     |                                                                                        |    DNA integrity scanning protein DisA    | -                           |               |                     |                 |                    |
| A0AC59FUI5 |   73   | 9.09  |       9.35        |   -1.79    |    0.14     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      0      |                      |                                                                                        |          Uncharacterized protein          | -                           |               |                     |                 |                    |
| A0AC59FUI6 |  401   | 45.17 |       7.66        |   -0.22    |    0.07     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         1          |      5      |     KEEL[23-27]      |             NNT[48-51];NES[135-138];NLS[224-227];NES[267-270];NLS[356-359]             |           Glycosyl transferase            | -                           |               |                     |                 |                    |
| A0AC59FUI7 |  164   | 19.05 |       6.82        |   -0.74    |    0.10     |  Extracellular  |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      1      |                      |                                       NTT[73-76]                                       |            DNA repair protein             | -                           |               |                     |                 |                    |
| A0AC59FUJ0 |  116   | 12.37 |       4.90        |   -0.31    |    0.02     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         1          |      0      |     QQEL[34-38]      |                                                                                        |   DNA-binding protein, YbaB/EbfC family   | -                           |               |                     |                 |                    |
| A0AC59FUJ1 |  642   | 72.00 |       5.45        |   -0.37    |    0.08     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      1      |                      |                                       NMT[45-48]                                       |       Translation elongation factor       | -                           |               |                     |                 |                    |
| A0AC59FUJ2 |   31   | 3.81  |       9.70        |   -1.04    |    0.10     |     Nucleus     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      0      |                      |                                                                                        |          Uncharacterized protein          | -                           |               |                     |                 |                    |
| A0AC59FUJ3 |  388   | 45.46 |       5.40        |   -0.46    |    0.14     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      1      |                      |                                      NGS[345-348]                                      |             Beta-glucosidase              | -                           |               |                     |                 |                    |
| A0AC59FUJ4 |  545   | 62.81 |       5.02        |   -0.35    |    0.06     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      3      |                      |                          NNS[96-99];NRS[492-495];NES[541-544]                          |   DNA polymerase III subunits gamma/tau   | -                           |               |                     |                 |                    |
| A0AC59FUJ5 |   68   | 7.60  |       5.33        |   -0.06    |    0.04     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      0      |                      |                                                                                        |       RNA-binding mediating protein       | -                           |               |                     |                 |                    |
| A0AC59FUJ6 |  293   | 32.91 |       9.03        |    0.17    |    0.11     | Plasma membrane |    3    |     3      |    -    |         3          | PHOBIUS_TM&#124;SL&#124;TM |    -     |     -      |         0          |      7      |                      | NIT[14-17];NFS[26-29];NKT[163-166];NYT[180-183];NIS[194-197];NNT[233-236];NNT[281-284] |   Mechanosensitive ion channel protein    | -                           |               |                     |                 |                    |
| A0AC59FUJ7 |  317   | 35.38 |       7.52        |   -0.16    |    0.05     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         1          |      3      |     KQEL[91-95]      |                         NVT[134-137];NST[216-219];NHS[304-307]                         |         Transcriptional regulator         | -                           |               |                     |                 |                    |
| A0AC59FUJ8 |  169   | 19.30 |       6.52        |   -0.26    |    0.06     |     Cytosol     |    0    |     0      |    -    |         0          |                            |    -     |     -      |         0          |      1      |                      |                                       NVS[30-33]                                       |      Small-molecule-binding protein       | -                           |               |                     |                 |                    |
##### Only top 10 proteins

---

##### Do you have a question or tips? Please contact us! E-mail: renato.simoes@ifsc.edu.br
Generated time: Tue Apr 07 23:23:17 UTC 2026