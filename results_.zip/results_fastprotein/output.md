FastProtein Software 1.0
========================
##### Protein Information Software

---
### Summary
| Information                          | Value              |
| ------------------------------------ | ------------------ |
| Processed proteins                   | 79                 |
| Molecular mass (kda) mean            | 19.91 &#177; 14.11 |
| Isoelectric point mean               | 7.14 &#177; 2.01   |
| Hydrophicity mean                    | -0.45 &#177; 0.30  |
| Aromaticity mean                     | 0.09 &#177; 0.03   |
| Proteins with TM                     | 6                  |
| Proteins with SP                     | 2                  |
| Proteins with GPI                    | 0                  |
| Membrane proteins                    | 6                  |
| Proteins with E.R Retention domains  | 6                  |
| Proteins with NGlycosylation domains | 53                 |
### Molecular mass (kDa) vs Isoelectric point (pH)
![Molecular mass (kDa) vs Isoelectric point (pH)](image/kda-vs-pi.png)
---
### Subcellular localization (by WolfPSort) - Organism: animal

![Subcellular Localizations](image/subcell-resume-bar.png)
![Subcellular Localizations](image/subcell-resume-pie.png)

| Subcellular localization | Proteins |
| ------------------------ | -------- |
| Cytosol                  | 53       |
| Extracellular            | 14       |
| Other                    | 5        |
| Nucleus                  | 3        |
| Mitochondrion            | 2        |
| Plasma membrane          | 1        |
| Cytoskeleton             | 1        |
---
### E.R Retention domain summary
| Domain | Quantity |
| ------ | -------- |
| ADEL   | 1        |
| HEEL   | 1        |
| KNEL   | 1        |
| KQEL   | 1        |
| SEEL   | 2        |
---
### NGlyc domain summary
| Domain | Quantity |
| ------ | -------- |
| NAT    | 6        |
| NQT    | 5        |
| NLS    | 5        |
| NKT    | 5        |
| NKS    | 8        |
| NLT    | 7        |
| NGT    | 5        |
| NES    | 9        |
| NFT    | 5        |
| NST    | 5        |
Only top 10

---
| Id     | Length |  kDa  | Isoelectric_Point | Hydropathy | Aromaticity | Localization  | TMHMM_2 | Phobius_TM | PredGPI | Membrane_evidences | Membrane_evidences_detail | SignalP5 | Phobius_SP | ER_Retention_Total | NGlyc_Total | ER_Retention_Domains |                  NGlyc_Domains                  |                                Header                                | Local_alignment_description | Gene_Ontology | Interpro_Annotation | PFAM_Annotation | Panther_Annotation |
| ------ |:------:|:-----:|:-----------------:|:----------:|:-----------:|:-------------:|:-------:|:----------:|:-------:|:------------------:|:-------------------------:|:--------:|:----------:|:------------------:|:-----------:|:--------------------:|:-----------------------------------------------:|:--------------------------------------------------------------------:| --------------------------- | ------------- | ------------------- | --------------- | ------------------ |
| Q24LF5 |  368   | 43.21 |       9.46        |   -0.45    |    0.10     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         1          |      2      |    KNEL[271-275]     |            NAT[316-319];NLS[360-363]            |                              Integrase                               | -                           |               |                     |                 |                    |
| Q24LH4 |  207   | 22.50 |       9.17        |   -0.68    |    0.08     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      2      |                      |             NNT[59-62];NAT[136-139]             |                  NlpC/P60 domain-containing protein                  | -                           |               |                     |                 |                    |
| Q24LI4 |  356   | 40.04 |       5.09        |   -0.22    |    0.06     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         1          |      2      |    KQEL[289-293]     |            NFT[147-150];NFT[296-299]            |                         Tail sheath protein                          | -                           |               |                     |                 |                    |
| Q24LJ4 |  451   | 52.53 |       5.23        |   -0.55    |    0.11     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      3      |                      |     NQT[131-134];NAS[335-338];NFT[447-450]      |                            Portal protein                            | -                           |               |                     |                 |                    |
| Q24LB9 |   76   | 8.97  |       9.04        |   -0.44    |    0.12     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      0      |                      |                                                 |                             Transposase                              | -                           |               |                     |                 |                    |
| Q24LC0 |   99   | 11.53 |       8.89        |    0.26    |    0.12     |    Cytosol    |    1    |     1      |    -    |         2          |    PHOBIUS_TM&#124;TM     |    -     |     -      |         0          |      0      |                      |                                                 |                       Uncharacterized protein                        | -                           |               |                     |                 |                    |
| Q24LC1 |  314   | 37.40 |       4.91        |   -0.45    |    0.11     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      1      |                      |                  NLS[101-104]                   |                  DUF4868 domain-containing protein                   | -                           |               |                     |                 |                    |
| Q24LC2 |   81   | 9.43  |       5.40        |   -0.29    |    0.07     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      0      |                      |                                                 |                       Uncharacterized protein                        | -                           |               |                     |                 |                    |
| Q24LC3 |  203   | 23.18 |       8.99        |   -0.33    |    0.10     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      2      |                      |             NLS[7-10];NYS[119-122]              |                            Phage protein                             | -                           |               |                     |                 |                    |
| Q24LC4 |   64   | 7.36  |       10.13       |   -0.46    |    0.06     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      0      |                      |                                                 |                       Uncharacterized protein                        | -                           |               |                     |                 |                    |
| Q24LC5 |  162   | 19.53 |       9.13        |   -0.77    |    0.09     | Extracellular |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      1      |                      |                   NSS[60-63]                    |                             Sigma factor                             | -                           |               |                     |                 |                    |
| Q24LC6 |  235   | 27.84 |       8.97        |   -0.68    |    0.09     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      3      |                      |      NST[66-69];NRT[110-113];NES[126-129]       |          AntA/AntB antirepressor domain-containing protein           | -                           |               |                     |                 |                    |
| Q24LC7 |  117   | 13.67 |       9.90        |   -0.73    |    0.10     |     Other     |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      2      |                      |               NFT[3-6];NKT[29-32]               |                     Holliday junction resolvase                      | -                           |               |                     |                 |                    |
| Q24LC8 |  268   | 31.27 |       8.99        |   -0.63    |    0.10     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         1          |      2      |    HEEL[203-207]     |            NKT[171-174];NKS[235-238]            |                          Methyltransferase                           | -                           |               |                     |                 |                    |
| Q24LC9 |   79   | 9.29  |       9.25        |   -0.54    |    0.14     | Extracellular |    0    |     0      |    -    |         0          |                           |    -     |     -      |         1          |      0      |     ADEL[16-20]      |                                                 |                       Uncharacterized protein                        | -                           |               |                     |                 |                    |
| Q24LD0 |   61   | 7.33  |       4.73        |   -0.62    |    0.11     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      0      |                      |                                                 |                            Phage protein                             | -                           |               |                     |                 |                    |
| Q24LD1 |  155   | 18.04 |       4.72        |   -0.27    |    0.09     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         1          |      0      |    SEEL[144-148]     |                                                 |                       Uncharacterized protein                        | -                           |               |                     |                 |                    |
| Q24LD2 |  123   | 14.65 |       4.54        |   -0.71    |    0.14     | Extracellular |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      1      |                      |                   NQS[19-22]                    |                       Uncharacterized protein                        | -                           |               |                     |                 |                    |
| Q24LD3 |   57   | 6.59  |       4.53        |   -0.76    |    0.07     | Extracellular |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      0      |                      |                                                 |                       Uncharacterized protein                        | -                           |               |                     |                 |                    |
| Q24LD4 |  234   | 28.02 |       8.99        |   -0.62    |    0.14     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      0      |                      |                                                 | Phosphoadenosine phosphosulphate reductase domain-containing protein | -                           |               |                     |                 |                    |
| Q24LD5 |  122   | 14.45 |       5.82        |   -0.89    |    0.10     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      1      |                      |                  NGT[105-108]                   |                       Uncharacterized protein                        | -                           |               |                     |                 |                    |
| Q24LD6 |  218   | 25.33 |       5.66        |   -0.38    |    0.11     | Cytoskeleton  |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      4      |                      | NNS[76-79];NAT[92-95];NNS[121-124];NAT[191-194] |                     Nucleoid-associated protein                      | -                           |               |                     |                 |                    |
| Q24LD7 |  110   | 12.29 |       9.62        |   -0.66    |    0.06     |    Cytosol    |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      0      |                      |                                                 |                 DNA (cytosine-5-)-methyltransferase                  | -                           |               |                     |                 |                    |
| Q24LD8 |  260   | 30.13 |       9.71        |   -0.51    |    0.11     | Mitochondrion |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      1      |                      |                   NLS[42-45]                    |                 DNA (cytosine-5-)-methyltransferase                  | -                           |               |                     |                 |                    |
| Q24LD9 |  111   | 13.10 |       4.43        |   -0.17    |    0.09     | Extracellular |    0    |     0      |    -    |         0          |                           |    -     |     Y      |         1          |      1      |    SEEL[104-108]     |                   NKS[50-53]                    |                       Uncharacterized protein                        | -                           |               |                     |                 |                    |
| Q24LE0 |   57   | 6.63  |       5.24        |   -0.67    |    0.09     | Extracellular |    0    |     0      |    -    |         0          |                           |    -     |     -      |         0          |      0      |                      |                                                 |                  DUF3797 domain-containing protein                   | -                           |               |                     |                 |                    |
##### Only top 10 proteins

---

##### Do you have a question or tips? Please contact us! E-mail: renato.simoes@ifsc.edu.br
Generated time: Sat Apr 04 17:55:39 UTC 2026